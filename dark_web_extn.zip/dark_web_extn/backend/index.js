const express = require('express');
const cors = require('cors');
const tr = require('tor-request');
const cheerio = require('cheerio');
const async = require('async');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3000;

// Set Tor Proxy
tr.setTorAddress("127.0.0.1", 9050);

// Search function using Tor
app.post('/search', async (req, res) => {
  const { keyword } = req.body;
  if (!keyword) return res.status(400).json({ error: "Keyword is required" });

  console.log(`🔍 Searching dark web for: ${keyword}`);

  let getToken = new Promise((resolve, reject) => {
    tr.request("http://xmh57jrknzkhv6y3ls3ubitzfqnkrwxhopf5aygthi7d6rplyvk3noyd.onion/cgi-bin/omega/omega", function (err, response, body) {
      if (!err && response.statusCode == 200) {
        const $ = cheerio.load(body);
        const tokenValue = $('#tkn').attr('value');

        console.log(`✅ Token retrieved: ${tokenValue}`);
        resolve(tokenValue);
      } else {
        reject(err || "Failed to get token");
      }
    });
  });

  try {
    const token = await getToken;

    tr.request(`http://xmh57jrknzkhv6y3ls3ubitzfqnkrwxhopf5aygthi7d6rplyvk3noyd.onion/cgi-bin/omega/omega?P=${keyword}&DEFAULTOP=and&DB=default&FMT=query&xDB=default&xFILTERS=.%7E%7E&tkn=${token}`, function (err, response, body) {
      if (err || response.statusCode !== 200) {
        console.error(`❌ Error fetching results:`, err);
        return res.status(500).json({ error: "Failed to fetch search results" });
      }

      const $ = cheerio.load(body);
      const results = [];

      $('table tr').each((index, row) => {
        const $tds = $(row).find('td');
        if ($tds.length >= 2) {
          results.push({
            keyword,
            timestamp: Math.floor(Date.now() / 1000),
            title: $tds.eq(1).find("b a").text().trim(),
            description: $tds.eq(1).find("small:first").text().trim(),
            url: $tds.eq(1).find("a").attr("href"),
          });
        }
      });

      console.log(`✅ Found ${results.length} results for "${keyword}"`);
      res.json({ results });
    });

  } catch (error) {
    console.error("❌ Error during search:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.listen(PORT, () => console.log(`🚀 Dark Web API running on http://localhost:${PORT}`));
