document.getElementById("searchBtn").addEventListener("click", async () => {
  const keyword = document.getElementById("keyword").value.trim();
  if (!keyword) {
    alert("Please enter a keyword!");
    return;
  }

  document.getElementById("loader").classList.remove("hidden");
  document.getElementById("results").innerHTML = "";

  try {
    const response = await fetch("http://localhost:3000/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ keyword }),
    });

    const data = await response.json();
    document.getElementById("loader").classList.add("hidden");

    if (!data.results.length) {
      document.getElementById("results").innerHTML = `<p style="color: white;">No results found.<br> You are Safe!!!</p>`;
      return;
    }

    document.getElementById("results").innerHTML = data.results
      .map(result => `
              <div class="result-item">
                  <strong>${result.title}</strong><br>
                  <small>${result.description}</small><br>
                  <a href="${result.url}" target="_blank">🔗 View</a>
              </div>
          `)
      .join("");

  } catch (error) {
    document.getElementById("loader").classList.add("hidden");
    document.getElementById("results").innerHTML = `<p style="color: red;">Error fetching results.</p>`;
  }
});
