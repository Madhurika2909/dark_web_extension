chrome.runtime.onInstalled.addListener(() => {
  console.log("Dark Web Monitor Extension Installed");
});
